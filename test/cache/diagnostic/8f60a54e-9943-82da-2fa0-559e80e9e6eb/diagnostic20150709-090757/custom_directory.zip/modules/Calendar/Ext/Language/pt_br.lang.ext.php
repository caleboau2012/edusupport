<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_SECURITYGROUPS'] = 'Lista de usu�rio do filtro pelo Grupos de Seguran�a';

?>