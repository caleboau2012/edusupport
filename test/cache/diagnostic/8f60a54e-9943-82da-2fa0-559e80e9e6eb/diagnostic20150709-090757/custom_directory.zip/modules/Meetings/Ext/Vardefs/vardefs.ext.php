<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2014-01-20 12:22:31

 


 // created: 2014-01-20 12:22:32

 


 // created: 2014-01-20 12:22:32

 



$dictionary['Meeting']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_meetings',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);






 // created: 2014-01-20 12:22:32

 

?>