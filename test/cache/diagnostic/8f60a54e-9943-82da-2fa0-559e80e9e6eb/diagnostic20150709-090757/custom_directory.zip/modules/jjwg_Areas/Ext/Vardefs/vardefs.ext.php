<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-11-12 15:42:44
$dictionary["jjwg_Areas"]["fields"]["jjwg_maps_jjwg_areas"] = array (
  'name' => 'jjwg_maps_jjwg_areas',
  'type' => 'link',
  'relationship' => 'jjwg_maps_jjwg_areas',
  'source' => 'non-db',
  'vname' => 'LBL_JJWG_MAPS_JJWG_AREAS_FROM_JJWG_MAPS_TITLE',
);


// created: 2010-11-12 15:50:53
$dictionary["jjwg_Areas"]["fields"]["jjwg_maps_jjwg_areas"] = array (
  'name' => 'jjwg_maps_jjwg_areas',
  'type' => 'link',
  'relationship' => 'jjwg_maps_jjwg_areas',
  'source' => 'non-db',
  'vname' => 'LBL_JJWG_MAPS_JJWG_AREAS_FROM_JJWG_MAPS_TITLE',
);


// created: 2010-11-12 15:50:54
$dictionary["jjwg_Areas"]["fields"]["jjwg_maps_jjwg_areas"] = array (
  'name' => 'jjwg_maps_jjwg_areas',
  'type' => 'link',
  'relationship' => 'jjwg_maps_jjwg_areas',
  'source' => 'non-db',
  'vname' => 'LBL_JJWG_MAPS_JJWG_AREAS_FROM_JJWG_MAPS_TITLE',
);


?>