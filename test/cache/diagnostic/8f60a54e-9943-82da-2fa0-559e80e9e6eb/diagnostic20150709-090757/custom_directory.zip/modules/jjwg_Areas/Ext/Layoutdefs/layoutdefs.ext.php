<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-11-12 15:42:44
$layout_defs["jjwg_Areas"]["subpanel_setup"]["jjwg_maps_jjwg_areas"] = array (
  'order' => 100,
  'module' => 'jjwg_Maps',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_JJWG_MAPS_JJWG_AREAS_FROM_JJWG_MAPS_TITLE',
  'get_subpanel_data' => 'jjwg_maps_jjwg_areas',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2010-11-12 15:50:53
$layout_defs["jjwg_Areas"]["subpanel_setup"]["jjwg_maps_jjwg_areas"] = array (
  'order' => 100,
  'module' => 'jjwg_Maps',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_JJWG_MAPS_JJWG_AREAS_FROM_JJWG_MAPS_TITLE',
  'get_subpanel_data' => 'jjwg_maps_jjwg_areas',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2010-11-12 15:50:54
$layout_defs["jjwg_Areas"]["subpanel_setup"]["jjwg_maps_jjwg_areas"] = array (
  'order' => 100,
  'module' => 'jjwg_Maps',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_JJWG_MAPS_JJWG_AREAS_FROM_JJWG_MAPS_TITLE',
  'get_subpanel_data' => 'jjwg_maps_jjwg_areas',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


?>