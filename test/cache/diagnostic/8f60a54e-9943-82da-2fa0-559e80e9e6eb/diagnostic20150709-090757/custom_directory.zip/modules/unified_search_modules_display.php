<?php
// created: 2015-06-15 07:36:38
$unified_search_modules_display = array (
  'Contacts' => 
  array (
    'visible' => true,
  ),
  'Accounts' => 
  array (
    'visible' => true,
  ),
  'AOP_Case_Updates' => 
  array (
    'visible' => true,
  ),
  'AOR_Reports' => 
  array (
    'visible' => true,
  ),
  'Calls' => 
  array (
    'visible' => true,
  ),
  'Cases' => 
  array (
    'visible' => true,
  ),
  'Notes' => 
  array (
    'visible' => true,
  ),
  'AOP_Case_Events' => 
  array (
    'visible' => true,
  ),
  'AOS_Contracts' => 
  array (
    'visible' => false,
  ),
  'AOS_Invoices' => 
  array (
    'visible' => false,
  ),
  'AOS_PDF_Templates' => 
  array (
    'visible' => false,
  ),
  'AOS_Product_Categories' => 
  array (
    'visible' => false,
  ),
  'AOS_Products' => 
  array (
    'visible' => false,
  ),
  'AOS_Quotes' => 
  array (
    'visible' => false,
  ),
  'AOW_Processed' => 
  array (
    'visible' => false,
  ),
  'AOW_WorkFlow' => 
  array (
    'visible' => false,
  ),
  'Bugs' => 
  array (
    'visible' => false,
  ),
  'Calls_Reschedule' => 
  array (
    'visible' => false,
  ),
  'Campaigns' => 
  array (
    'visible' => false,
  ),
  'Documents' => 
  array (
    'visible' => false,
  ),
  'FP_Event_Locations' => 
  array (
    'visible' => false,
  ),
  'FP_events' => 
  array (
    'visible' => false,
  ),
  'Leads' => 
  array (
    'visible' => false,
  ),
  'Meetings' => 
  array (
    'visible' => false,
  ),
  'Opportunities' => 
  array (
    'visible' => false,
  ),
  'Project' => 
  array (
    'visible' => false,
  ),
  'ProjectTask' => 
  array (
    'visible' => false,
  ),
  'ProspectLists' => 
  array (
    'visible' => false,
  ),
  'Prospects' => 
  array (
    'visible' => false,
  ),
  'Tasks' => 
  array (
    'visible' => false,
  ),
  'jjwg_Address_Cache' => 
  array (
    'visible' => false,
  ),
  'jjwg_Areas' => 
  array (
    'visible' => false,
  ),
  'jjwg_Maps' => 
  array (
    'visible' => false,
  ),
  'jjwg_Markers' => 
  array (
    'visible' => false,
  ),
);