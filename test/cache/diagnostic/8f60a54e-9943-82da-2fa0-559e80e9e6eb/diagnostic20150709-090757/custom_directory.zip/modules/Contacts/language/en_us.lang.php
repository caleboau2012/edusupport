<?php
// created: 2015-06-17 08:21:08
$mod_strings = array (
  'LBL_ID' => 'ID',
  'LBL_TITLE' => 'Middle Name',
  'LBL_ALT_ADDRESS' => 'Address',
  'LBL_ALT_ADDRESS_CITY' => 'Session',
  'LBL_ALT_ADDRESS_STATE' => 'VigiConnect Username',
);