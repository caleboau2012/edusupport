<?php 
 // created: 2014-10-03 16:50:58
$mod_strings['LBL_LIST_ASSIGNED_USER_ID'] = 'Resource';
$mod_strings['LBL_DESCRIPTION'] = 'Notes';
$mod_strings['LBL_SUBTASK'] = 'Sub-Task';
$mod_strings['LBL_LAG'] = 'Lag';
$mod_strings['LBL_DAYS'] = 'Days';
$mod_strings['LBL_HOURS'] = 'Hours';
$mod_strings['LBL_PREDECESSORS'] = 'Predecessor';
$mod_strings['LBL_PARENT_TASK_ID'] = 'Parent Task Id';
$mod_strings['LBL_LIST_PERCENT_COMPLETE'] = '% Complete';
$mod_strings['LBL_PERCENT_COMPLETE'] = '% Cpl';
$mod_strings['LBL_RELATIONSHIP_TYPE'] = 'Relationship Type';

?>
