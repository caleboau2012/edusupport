<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_FP_EVENTS_FP_EVENT_LOCATIONS_1_FROM_FP_EVENTS_TITLE'] = 'Eventos';
$mod_strings['LBL_FP_EVENT_LOCATIONS_FP_EVENTS_1_FROM_FP_EVENTS_TITLE'] = 'Eventos';

?>