<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2013-04-25 10:18:48
$dictionary["FP_Event_Locations"]["fields"]["fp_event_locations_fp_events_1"] = array (
  'name' => 'fp_event_locations_fp_events_1',
  'type' => 'link',
  'relationship' => 'fp_event_locations_fp_events_1',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_FP_EVENT_LOCATIONS_FP_EVENTS_1_FROM_FP_EVENTS_TITLE',
);

?>