<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => "Группы пользователей",
	)
);


$mod_strings = array (
    'LBL_RESCHEDULE' => 'Отложить звонок',
    'LBL_RESCHEDULE_COUNT' => 'Попыток дозвона',
    'LBL_RESCHEDULE_DATE' => 'Дата',
    'LBL_RESCHEDULE_REASON' => 'Причина',
    'LBL_RESCHEDULE_ERROR1' => 'Укажите правильную дату',
    'LBL_RESCHEDULE_ERROR2' => 'Укажите причину, по которой звонок отложен',
    'LBL_RESCHEDULE_PANEL' => 'Отложенные звонки',
    'LBL_RESCHEDULE_HISTORY' => 'История дозвона'

);

?>