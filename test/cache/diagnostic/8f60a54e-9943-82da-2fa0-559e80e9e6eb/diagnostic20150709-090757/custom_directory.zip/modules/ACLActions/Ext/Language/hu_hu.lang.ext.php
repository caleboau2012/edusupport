<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings = array_merge($mod_strings,
	array(
  		'LBL_ACCESS_GROUP' => 'Csoport',
	)
);


?>