<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
 $hook_version = 1; 
$hook_array = Array(); 
// position, file, function

$hook_array['before_delete'] = Array();
$hook_array['before_delete'][] = Array(1, 'Delete Project Tasks', 'custom/modules/Project/delete_project_tasks.php','delete_project_tasks', 'delete_tasks');
?>