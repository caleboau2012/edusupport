<?php
// created: 2014-02-03 12:55:32
$mapping = array (
  'beans' => 
  array (
    'Accounts' => 
    array (
    ),
    'Contacts' => 
    array (
    ),
    'Leads' => 
    array (
    ),
  ),
);