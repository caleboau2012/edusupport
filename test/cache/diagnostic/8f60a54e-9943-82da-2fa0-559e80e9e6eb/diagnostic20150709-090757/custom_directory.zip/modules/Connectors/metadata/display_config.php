<?php
// created: 2014-01-18 20:47:29
$modules_sources = array (
  'Accounts' => 
  array (
    'ext_rest_linkedin' => 'ext_rest_linkedin',
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Contacts' => 
  array (
    'ext_rest_linkedin' => 'ext_rest_linkedin',
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Leads' => 
  array (
    'ext_rest_linkedin' => 'ext_rest_linkedin',
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Prospects' => 
  array (
    'ext_rest_linkedin' => 'ext_rest_linkedin',
  ),
  'Opportunities' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
);