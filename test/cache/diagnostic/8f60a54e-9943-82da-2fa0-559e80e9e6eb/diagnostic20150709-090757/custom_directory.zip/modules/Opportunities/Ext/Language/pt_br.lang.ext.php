<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => "Grupos de Segurança",
	)
);


?>