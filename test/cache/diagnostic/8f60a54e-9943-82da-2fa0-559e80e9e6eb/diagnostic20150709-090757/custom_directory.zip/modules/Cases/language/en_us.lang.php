<?php
// created: 2015-06-24 08:31:45
$mod_strings = array (
  'LBL_COMM_CHANNEL' => 'Communication Channel',
  'LBL_LOCATION' => 'Location',
  'LBL_TYPE' => 'Type',
  'LBL_DETAILVIEW_PANEL1' => 'New Panel 1',
);