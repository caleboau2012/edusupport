<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = "Gestione Gruppi di Security Suite";
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = "Editor Gruppi di Security Suite.";
$mod_strings['LBL_SECURITYGROUPS'] = "Security Suite";
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = "Impostazioni di Security Suite";
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = "Configura le impostazioni di Security Suite come ereditarieta` dei gruppi, sicurezza aggiunta, etc.";
$mod_strings['LBL_SECURITYGROUPS'] = "Security Suite";
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Aggiornamento e Informazioni Generali";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Informazioni su Security Suite";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Informazioni Generali.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Forza pubblicazione Dashlet dei Messaggi";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Pubblica la Dashlet dei Messaggi nell'Home Page di tutti gli utenti. Questo processo potrebbe richiedere del tempo in base al numero degli utenti.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Modulo per l'Integrazione";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Integra Security Suite con i tuoi moduli custom.";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Scarica l'ultima versione di SecuritySuite e trovare altri moduli di SugarCRM, temi e integrazioni con commenti, documenti, supporto, e le versioni verificate comunit�.";


?>