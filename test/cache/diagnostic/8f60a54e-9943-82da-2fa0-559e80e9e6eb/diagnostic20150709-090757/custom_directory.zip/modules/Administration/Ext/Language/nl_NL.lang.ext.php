<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Security Suite Groep Beheer';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Security Suite Groep Editor';
$mod_strings['LBL_SECURITYGROUPS'] = 'Security Suite';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Security Suite Instellingen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Configureer Security Suite instellingen zoals Groep Erven, Stapelende Beveiliging, etc';
$mod_strings['LBL_SECURITYGROUPS'] = 'Security Suite';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Upgrade en Algemene Info";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Security Suite Info";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Algemene informatie";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Push Bericht Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Push de Berichten Dashlet naar het hoofd-scherm voor alle gebruikers. Afhankelijk van het aantal gebruikers kan dit proces kan enige tijd in beslag nemen.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Aansluit Module";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Sluit Security Suite aan om met uw custom modules te werken";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Pak de nieuwste versie van SecuritySuite en vind andere SugarCRM modules, thema's, en integraties met reviews, documenten, ondersteuning, en de gemeenschap gecontroleerde uitvoeringen.";


?>