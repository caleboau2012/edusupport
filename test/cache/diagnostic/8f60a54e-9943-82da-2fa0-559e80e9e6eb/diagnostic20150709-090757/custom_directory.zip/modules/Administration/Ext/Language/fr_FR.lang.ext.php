<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "Mise à jour de QuickCRM Mobile";
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Actualisation de QuickCRM Mobile";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Application updated for QuickCRM on mobile</strong><br/>You can access the mobile version at:';
$mod_strings['LBL_ERR_DIR_MSG'] = "Certains fichiers n'ont pu être créés. Vérifiez les droits d'accès pour le dossier : ";





$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = "Gestion des équipes";
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = "Permet de créer et d'éditer les équipes et leurs droits d'accès";
$mod_strings['LBL_SECURITYGROUPS'] = 'Equipes';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = "Configuration des équipes";
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = "Permet d'éditer les paramètres des équipes";
$mod_strings['LBL_SECURITYGROUPS'] = 'Equipes';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = 'Mise à niveau et informations générales';
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "L'information de suite de sécurité";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = 'Informations générales';
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Poussez le message Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Poussez le message Dashlet à la page d'accueil pour tous les utilisateurs. Ce processus peut prendre un certain temps d'accomplir selon le nombre d'utilisateurs";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Module de conjugaison";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Suite de sécurité de conjugaison à travailler avec vos modules faits sur commande";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Téléchargez la dernière version de SecuritySuite et trouver d'autres modules de SugarCRM, des thèmes et des intégrations avec commentaires, docs, le soutien et les versions vérifiées communautaires.";


?>