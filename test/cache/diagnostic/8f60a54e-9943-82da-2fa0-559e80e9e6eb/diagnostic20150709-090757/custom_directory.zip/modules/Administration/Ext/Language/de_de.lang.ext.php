<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "QuickCRM Aktualisierung";
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Konfiguration aktualisieren";
$mod_strings['LBL_CONFIG_QUICKCRM_TITLE'] = "Ansichten konfigurieren";
$mod_strings['LBL_CONFIG_QUICKCRM'] = "Definition von Anzeige- und Suchfeldern";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Anwendung für die mobile Nutzung unter QuickCRM aktualisiert</strong><br/>Zugriff auf die mobile Version:';

$mod_strings['LBL_ERR_DIR_MSG'] = 'Einige Dateien konnten nicht erstellt werden. Bitte prüfen Sie die Schreibberechtigungen für: ';





$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen Verwaltung';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Berechtigungsgruppen bearbeiten';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen Einstellungen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Die Einstellungen für Berechtigungsgruppen anpassen - Vererbungsregeln, additive Rechte etc.';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Aktualisierung und generelle Infos";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Berechtigungsgruppen Info";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Generelle Informationen";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Nachrichten Dashlet verteilen";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Machen Sie das Nachrichten Dashlet auf der Startseite aller Benutzer sichtbar. Dieser Vorgang kann, abhängig von der Anzahl der Benutzer, ein bisschen dauern.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Modul verbinden";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Selbst erstellte Module mit Berechtigungsgruppen verbinden";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Holen Sie sich die neueste Version der Berechtigungsgruppen bzw. andere SugarCRM Module, Designs und Integrationen zusammen mit Bewertungen, Dokumenten, Unterstützung und von der Community bestätigten Versionen.";



?>