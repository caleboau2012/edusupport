<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_JJWG_MAPS_ADMIN_HEADER'] = 'Google Mapas';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DESC'] = 'Gerenciar seu geocodificação, geocodificação testar, ver geocodificação totais resultado e definir configurações avançadas.';
$mod_strings['LBL_JJWG_MAPS_ADMIN_CONFIG_TITLE'] = 'Configurações do Google Mapas';
$mod_strings['LBL_JJWG_MAPS_ADMIN_CONFIG_DESC'] = 'As definições de configuração para ajustar seu Google Mapas';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODED_COUNTS_TITLE'] = 'Counts Georreferenciados';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODED_COUNTS_DESC'] = 'Mostra o número de objetos do módulo geocodificados, agrupados por resposta de geocodificação.';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DONATE_TITLE'] = 'Doações para este Projeto';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DONATE_DESC'] = 'Por favor, considere fazer uma doação para este projeto!';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODE_ADDRESSES_TITLE'] = 'Endereços Geocode';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODE_ADDRESSES_DESC'] = 'Geocode seus addreses objeto. Este processo pode demorar alguns minutos!';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODING_TEST_TITLE'] = 'Teste de Geocodificação';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODING_TEST_DESC'] = 'Executar um único teste de geocodificação com resultados exibição detalhada.';
$mod_strings['LBL_JJWG_MAPS_ADMIN_ADDRESS_CACHE_TITLE'] = 'Endereço Cache';
$mod_strings['LBL_JJWG_MAPS_ADMIN_ADDRESS_CACHE_DESC'] = 'Fornece acesso a informações de endereço Cache. Esta é apenas uma memória cache.';



$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Gerenciamento do Módulo de Grupos de Segurança';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Editor do Módulo de Grupos de Segurança';
$mod_strings['LBL_SECURITYGROUPS'] = 'Módulo de Grupos de Segurança';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Configurações do Módulo de Grupos de Segurança';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Configurações do Gerenciador do Módulo de Grupos de Segurança como herança, aditivo de segurança, etc';
$mod_strings['LBL_SECURITYGROUPS'] = 'Módulo de Grupos de Segurança';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Melhoramento e Informação Geral";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Informação Grupos de Segurança";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Informação Geral";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Empurre a mensagem Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Push the Message Dashlet to the Home page for all users. This process may take some time to complete depending on the number of users";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Módulo da conexão";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Série da Grupos de Segurança a trabalhar com seus módulos feitos sob encomenda";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Descarga la última versión de SecuritySuite y encontrar otros módulos SugarCRM, temas e integraciones con opiniones, documentos, soporte y versiones verificadas de la comunidad.";


?>