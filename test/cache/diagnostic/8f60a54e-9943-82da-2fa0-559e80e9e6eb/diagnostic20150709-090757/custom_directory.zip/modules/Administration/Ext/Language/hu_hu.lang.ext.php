<?php 
 //WARNING: The contents of this file are auto-generated

﻿

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Biztonsági Csoportok Kezelése';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Biztonsági Csoport Szerkesztő';
$mod_strings['LBL_SECURITYGROUPS'] = 'Biztonsági Csoportok';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Biztonsági Csoportok Beállításai';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Módosíthatók a Biztonsági Csoport beállításai, mint pl. az öröklődés, additív jogok, stb.';
$mod_strings['LBL_SECURITYGROUPS'] = 'Biztonsági Csoportok';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Frissítés és Általános Információ";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Információ a Biztonsági Csoportok-ról";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Általános Információ";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Csoportos Üzenet Műszer telepítése";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Minden felhasználó kezdőlapjára telepíti a Csoportos Üzenet Műszert. Ez a művelet hoszabb ideig is eltarhat, a felhasználók számától függően.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Modul Csatlakoztatása";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Biztonsági Csoport képesség hozzáadása egyedi modulhoz";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Fogd meg a legfrissebb SecuritySuite és talál más SugarCRM modul, témákat és integráció, értékelés, docs, támogatás, és a közösség ellenőrizni változatban.";


?>