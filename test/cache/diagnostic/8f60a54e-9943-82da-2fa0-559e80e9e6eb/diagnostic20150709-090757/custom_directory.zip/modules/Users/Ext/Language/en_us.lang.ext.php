<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings = array_merge($mod_strings,
    array(
         'LBL_LIST_NONINHERITABLE' => "Not Inheritable",
         'LBL_PRIMARY_GROUP' => "Primary Group",
    )
);

?>