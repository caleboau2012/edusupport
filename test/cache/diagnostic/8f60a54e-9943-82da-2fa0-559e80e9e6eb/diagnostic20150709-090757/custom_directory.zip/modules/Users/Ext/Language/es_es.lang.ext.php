<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings = array_merge($mod_strings,
    array(
         'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => "Grupos de Seguridad",
         'LBL_PRIMARY_GROUP' => "Grupo Principal",
         'LBL_SECURITYGROUP_NONINHERITABLE' => 'Grupo No-Heredable',
    )
);

?>