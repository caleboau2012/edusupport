<?php
// created: 2015-06-19 08:00:05
$mod_strings = array (
  'LBL_SUITE_POWERED_BY' => 'VGN 2015',
  'LBL_SUITE_SUPERCHARGED' => 'System Deployed by the EA Team',
);