<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2014-06-04 23:46:40
$dictionary["AM_ProjectTemplates"]["fields"]["am_projecttemplates_project_1"] = array (
  'name' => 'am_projecttemplates_project_1',
  'type' => 'link',
  'relationship' => 'am_projecttemplates_project_1',
  'source' => 'non-db',
  'module' => 'Project',
  'bean_name' => 'Project',
  'side' => 'right',
  'vname' => 'LBL_AM_PROJECTTEMPLATES_PROJECT_1_FROM_PROJECT_TITLE',
);


// created: 2014-05-30 00:06:35
$dictionary["AM_ProjectTemplates"]["fields"]["am_tasktemplates_am_projecttemplates"] = array (
  'name' => 'am_tasktemplates_am_projecttemplates',
  'type' => 'link',
  'relationship' => 'am_tasktemplates_am_projecttemplates',
  'source' => 'non-db',
  'module' => 'AM_TaskTemplates',
  'bean_name' => 'AM_TaskTemplates',
  'side' => 'right',
  'vname' => 'LBL_AM_TASKTEMPLATES_AM_PROJECTTEMPLATES_FROM_AM_TASKTEMPLATES_TITLE',
);

?>