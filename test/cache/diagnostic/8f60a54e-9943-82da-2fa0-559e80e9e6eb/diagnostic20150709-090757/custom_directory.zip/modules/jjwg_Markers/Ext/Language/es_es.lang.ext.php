<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_JJWG_MAPS_JJWG_MARKERS_FROM_JJWG_MAPS_TITLE'] = 'Mapas';

?>