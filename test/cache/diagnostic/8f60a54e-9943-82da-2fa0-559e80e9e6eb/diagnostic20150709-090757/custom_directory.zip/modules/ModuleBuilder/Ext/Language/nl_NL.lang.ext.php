<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_DEFAULT'] = 'Standaard';
$mod_strings['LBL_ADD_LAYOUT'] = 'Voeg Layout toe';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Voeg Layout toe';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'Kies een Groep Layout om toe te voegen.';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Verwijder Groep Layout';

$mod_strings['LBL_SECURITYGROUP'] = 'Security Groep:';
$mod_strings['LBL_COPY_FROM'] = 'Kopieer van:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Layout Opgeslagen';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'Layout Verwijderd';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Weet U het zeker?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Om een custom layout voor een Security Groep te maken, selecteer de betreffende Security Groep en kopieer vervolgens een layout om als startpunt te fungeren.";



?>