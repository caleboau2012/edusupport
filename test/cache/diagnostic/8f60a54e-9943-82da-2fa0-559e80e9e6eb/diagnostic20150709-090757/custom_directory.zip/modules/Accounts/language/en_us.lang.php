<?php
// created: 2015-06-24 09:15:46
$mod_strings = array (
  'LBL_STATE' => 'State:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Location:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Street',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_MATRIC_NUMBER' => 'Matric Number',
  'LBL_BILLING_ADDRESS_CITY' => 'City',
  'LBL_BILLING_ADDRESS_STATE' => 'State',
);