<?php
$hook_array['after_retrieve'] = Array();
$hook_array['after_retrieve'][] = Array(1, 'Decoded data', 'custom/modules/rolus_SMS_log/bodyDecode.php', 'bodyDecode', 'decoding64');
?>