<?php
	/**
	*  adding labels of newly added fields
	*
	**/
$mod_strings['LBL_LOGGED_IN'] = 'User Login Status';
$mod_strings['LBL_AVAILABILITY'] = 'User Availability';
$mod_strings['LBL_EXTENSION'] = 'Call Extension';
?>