<?php
$mod_strings['LBL_TWILIO_CALL_ID'] = 'Twilio Call Id';
$mod_strings['LBL_PRICE'] = 'Price';
$mod_strings['LBL_URI'] = 'Uri';
$mod_strings['LBL_RECORDINGS'] = 'Recordings';
$mod_strings['LBL_SOURCE'] = 'Source';
$mod_strings['LBL_DESTINATION'] = 'Destination';
$mod_strings['LBL_SYNC'] = 'Sync';
$mod_strings['LBL_RECORDINGS'] = 'Recordings';
?>