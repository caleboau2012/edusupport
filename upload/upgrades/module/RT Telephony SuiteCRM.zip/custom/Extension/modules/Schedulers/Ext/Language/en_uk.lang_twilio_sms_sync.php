<?php

$mod_strings['LBL_TWILIOSMSSYNC'] = 'RT SMS Sync'; 

?>