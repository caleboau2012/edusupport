<?php

$mod_strings['LBL_ROLUS_TWILIO_ACCOUNT_SETTINGS'] = 'Call Account';
$mod_strings['LBL_ROLUS_TWILIO_ACCOUNT_SETTINGS_DESC'] = 'Call Account management';

?>