<?php

$mod_strings['LBL_ROLUS_TWILIO_IVR_SETTINGS'] = 'IVR Settings';
$mod_strings['LBL_ROLUS_TWILIO_IVR_SETTINGS_DESC'] = 'IVR management';

?>