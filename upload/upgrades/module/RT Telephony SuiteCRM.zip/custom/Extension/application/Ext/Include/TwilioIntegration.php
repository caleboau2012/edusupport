<?php
	if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
?>
<?php

$beanList['rolus_SMS_log'] = 'rolus_SMS_log';
$beanFiles['rolus_SMS_log'] = 'modules/rolus_SMS_log/rolus_SMS_log.php';
$moduleList[] = 'rolus_SMS_log';

$beanList['rolus_Twilio_Account'] = 'rolus_Twilio_Account';
$beanFiles['rolus_Twilio_Account'] = 'modules/rolus_Twilio_Account/rolus_Twilio_Account.php';
$modules_exempt_from_availability_check['rolus_Twilio_Account'] = 'rolus_Twilio_Account';
$report_include_modules['rolus_Twilio_Account'] = 'rolus_Twilio_Account';
$modInvisList[] = 'rolus_Twilio_Account';


$beanList['rolus_Twilio_Extension_Manager'] = 'rolus_Twilio_Extension_Manager';
$beanFiles['rolus_Twilio_Extension_Manager'] = 'modules/rolus_Twilio_Extension_Manager/rolus_Twilio_Extension_Manager.php';
$modules_exempt_from_availability_check['rolus_Twilio_Extension_Manager'] = 'rolus_Twilio_Extension_Manager';
$report_include_modules['rolus_Twilio_Extension_Manager'] = 'rolus_Twilio_Extension_Manager';
$modInvisList[] = 'rolus_Twilio_Extension_Manager';


?>
