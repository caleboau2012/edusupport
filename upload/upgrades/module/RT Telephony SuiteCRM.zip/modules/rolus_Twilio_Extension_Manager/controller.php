<?php

class rolus_Twilio_Extension_ManagerController extends SugarController
{
    function rolus_Twilio_Extension_ManagerController()
	{
		parent::SugarController();
	}	
}
?>