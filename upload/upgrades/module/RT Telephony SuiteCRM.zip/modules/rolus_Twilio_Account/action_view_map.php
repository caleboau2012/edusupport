<?php

$action_view_map['multieditview']= 'list';
$action_view_map['detailview']= 'list';
$action_view_map['editview']= 'list';
$action_view_map['listview']= 'list';
$action_view_map['popup']= 'list';
$action_view_map['vcard']= 'list';
$action_view_map['importvcard']= 'list';
$action_view_map['importvcardsave']= 'list';
$action_view_map['modulelistmenu']= 'list';
$action_view_map['favorites']= 'list';
$action_view_map['ajaxui']= 'ajaxui';
$action_view_map['noaccess']= 'noaccess';

?>
