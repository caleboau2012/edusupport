<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$license_strings = array (
    'LBL_STEPS_TO_LOCATE_KEY_TITLE' => 'Per individuare la chiave',
    'LBL_STEPS_TO_LOCATE_KEY' => '1. Accedi per <a href="https://www.sugaroutfitters.com" target="_blank">SugarOutfitters</a><br/>2. Vai a Account->Purchases</br>3. Individuare la chiave per l\'acquisto di questo add-on<br/>4. Incollare nella casella Chiave di Licenza di seguito<br/>5. Fare clic su "Validate"',
    'LBL_LICENSE_KEY' => 'Chiave di Licenza',
    'LBL_CURRENT_USERS' => 'Conte utente corrente',
    'LBL_LICENSED_USERS' => 'Numero di utenti con licenza',
    'LBL_VALIDATE_LABEL' => 'Convalidare',
    'LBL_VALIDATED_LABEL' => 'Convalidato',
);

