<?php
 // created: 2015-06-24 09:06:17
$dictionary['Account']['fields']['matric_number_c']['labelValue']='Matric Number';

 ?>