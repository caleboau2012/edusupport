<?php
 // created: 2015-10-13 03:17:49
$dictionary['Lead']['fields']['refered_by']['inline_edit']=true;
$dictionary['Lead']['fields']['refered_by']['comments']='Identifies who refered the lead';
$dictionary['Lead']['fields']['refered_by']['merge_filter']='disabled';

 ?>