<?php
 // created: 2015-10-07 04:20:59
$dictionary['Lead']['fields']['howyouheardaboutus_c']['labelValue']='How did you hear about us?';

 ?>