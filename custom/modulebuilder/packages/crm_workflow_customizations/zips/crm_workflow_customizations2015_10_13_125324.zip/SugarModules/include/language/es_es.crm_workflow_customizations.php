<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Lead' => 'Lead',
  'Applicant' => 'Applicant',
  'Student' => 'Student',
);$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Web Site' => 'Sitio Web',
  'Other' => 'Otro',
  'data' => 'Data',
  'apply_portal' => 'Apply Portal',
  'enquiry' => 'Enquiry',
  'existing_customer' => 'Existing Customer',
);$app_list_strings['buying_power_list'] = array (
  '' => '',
  'Yes' => 'Yes',
  'No' => 'No',
);$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Calificación',
  'Closed Won' => 'Ganado',
  'Closed Lost' => 'Perdido',
  'initial_contact' => 'Initial Contact',
  'nurture' => 'Nurture',
  '' => '',
);