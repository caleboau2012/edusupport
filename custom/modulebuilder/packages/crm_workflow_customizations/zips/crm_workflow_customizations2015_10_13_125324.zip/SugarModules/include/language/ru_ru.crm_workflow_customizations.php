<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Lead' => 'Lead',
  'Applicant' => 'Applicant',
  'Student' => 'Student',
);$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Web Site' => 'Веб-сайт',
  'Other' => 'Другое',
  'data' => 'Data',
  'apply_portal' => 'Apply Portal',
  'enquiry' => 'Enquiry',
  'existing_customer' => 'Existing Customer',
);$app_list_strings['buying_power_list'] = array (
  '' => '',
  'Yes' => 'Yes',
  'No' => 'No',
);$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Оценка',
  'Closed Won' => 'Закрыто с успехом /Товар отгружен',
  'Closed Lost' => 'Закрыто с потерями /Товар возвращён',
  'initial_contact' => 'Initial Contact',
  'nurture' => 'Nurture',
  '' => '',
);