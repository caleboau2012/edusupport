<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Lead' => 'Lead',
  'Applicant' => 'Applicant',
  'Student' => 'Student',
);$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'data' => 'Data',
  'apply_portal' => 'Apply Portal',
  'Web Site' => 'Web Site',
  'enquiry' => 'Enquiry',
  'existing_customer' => 'Existing Customer',
  'Other' => 'Other',
);$app_list_strings['buying_power_list'] = array (
  '' => '',
  'Yes' => 'Yes',
  'No' => 'No',
);$app_list_strings['sales_stage_dom'] = array (
  '' => '',
  'initial_contact' => 'Initial Contact',
  'nurture' => 'Nurture',
  'Qualification' => 'Qualification',
  'Closed Won' => 'Closed Won',
  'Closed Lost' => 'Closed Lost',
);