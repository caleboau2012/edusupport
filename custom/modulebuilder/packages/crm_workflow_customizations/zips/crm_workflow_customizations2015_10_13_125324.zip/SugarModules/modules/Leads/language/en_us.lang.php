<?php 
 // created: 2015-10-13 12:53:21
$mod_strings['LBL_BUYING_POWER'] = 'Buying Power';
$mod_strings['LBL_INTEREST'] = 'Interest';
$mod_strings['LBL_SALES_STAGE'] = 'Sales Stage';
$mod_strings['LBL_HOWYOUHEARDABOUTUS'] = 'How did you hear about us?';
$mod_strings['LBL_REFERED_BY'] = 'How you heard about us:';

?>
