<?php 
$app_list_strings['case_type_dom'] = array (
  'device_issue' => 'Device Issue',
  'network_issue' => 'Network Issue',
  'vigilearn_issue' => 'Vigilearn Issue',
  'vigiconnect_issue' => 'Vigiconnect Issue',
  'eportal_issue' => 'E-portal Issue',
  'enquiry' => 'Enquiry',
  'others' => 'Others',
  'general_enquiry' => 'General Enquiry',
  'Payment_Issue' => 'Payment Issue',
);$app_list_strings['case_state_dom'] = array (
  'Open' => 'Abierto',
  'Closed' => 'Cerrado',
  'closed_as_lead' => 'Closed as Lead',
);$app_list_strings['comm_channel_list'] = array (
  'phonecall' => 'Phone Call',
  'email' => 'Email',
  'whatsapp' => 'WhatsApp',
  'vigiconnect' => 'VigiConnect',
  'bbm' => 'BBM',
  'weblms_forum' => 'WebLMS Forum',
);