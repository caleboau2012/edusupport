<?php
 // created: 2015-07-25 17:55:50
$dictionary['Case']['fields']['type']['default']='network_issue';
$dictionary['Case']['fields']['type']['len']=100;
$dictionary['Case']['fields']['type']['comments']='The type of issue (ex: issue, feature)';
$dictionary['Case']['fields']['type']['merge_filter']='disabled';

 ?>