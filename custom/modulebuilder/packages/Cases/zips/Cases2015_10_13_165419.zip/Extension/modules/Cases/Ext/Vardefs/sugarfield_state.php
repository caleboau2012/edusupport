<?php
 // created: 2015-09-29 07:32:44
$dictionary['Case']['fields']['state']['comments']='The state of the case (i.e. open/closed)';

 ?>