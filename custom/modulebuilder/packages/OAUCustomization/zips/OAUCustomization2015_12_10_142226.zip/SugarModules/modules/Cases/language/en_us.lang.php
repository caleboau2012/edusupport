<?php 
 // created: 2015-12-10 14:22:19
$mod_strings['LBL_COMM_CHANNEL'] = 'Communication Channel';
$mod_strings['LBL_LOCATION'] = 'Location';
$mod_strings['LBL_TYPE'] = 'Type';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_STATE'] = 'State:';
$mod_strings['LBL_REFERRED_BY'] = 'How you heard about us';

?>
