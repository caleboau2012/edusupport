<?php 
 // created: 2015-12-10 14:22:15
$mod_strings['LBL_STATE'] = 'State:';
$mod_strings['LBL_SHIPPING_ADDRESS_STREET'] = 'Location:';
$mod_strings['LBL_BILLING_ADDRESS_STREET'] = 'Billing Street';
$mod_strings['LBL_SIC_CODE'] = 'SIC Code:';
$mod_strings['LBL_MATRIC_NUMBER'] = 'Matric Number';
$mod_strings['LBL_BILLING_ADDRESS_CITY'] = 'City';
$mod_strings['LBL_BILLING_ADDRESS_STATE'] = 'State';
$mod_strings['LBL_HOW'] = 'How';
$mod_strings['LBL_SOURCE'] = 'Source';

?>
