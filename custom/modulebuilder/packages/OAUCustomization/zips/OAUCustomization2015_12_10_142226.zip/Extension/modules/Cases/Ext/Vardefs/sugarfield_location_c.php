<?php
 // created: 2015-06-24 08:24:43
$dictionary['Case']['fields']['location_c']['labelValue']='Location';

 ?>