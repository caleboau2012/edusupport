<?php
 // created: 2015-09-28 06:48:31
$dictionary['Account']['fields']['how_c']['labelValue']='How';

 ?>