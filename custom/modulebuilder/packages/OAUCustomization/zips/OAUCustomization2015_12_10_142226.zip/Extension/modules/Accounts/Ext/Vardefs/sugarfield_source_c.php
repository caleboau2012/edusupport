<?php
 // created: 2015-09-28 06:50:22
$dictionary['Account']['fields']['source_c']['labelValue']='Source';

 ?>