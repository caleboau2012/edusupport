<?php
 // created: 2015-09-28 07:03:48
$dictionary['Lead']['fields']['buying_power_c']['labelValue']='Buying Power';

 ?>