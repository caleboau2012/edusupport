<?php
 // created: 2015-09-28 07:05:35
$dictionary['Lead']['fields']['interest_c']['labelValue']='Interest';

 ?>