<?php
 // created: 2015-11-09 10:30:14
$dictionary['Lead']['fields']['date_modified']['audited']=true;
$dictionary['Lead']['fields']['date_modified']['inline_edit']=true;
$dictionary['Lead']['fields']['date_modified']['comments']='Date record last modified';
$dictionary['Lead']['fields']['date_modified']['merge_filter']='disabled';

 ?>