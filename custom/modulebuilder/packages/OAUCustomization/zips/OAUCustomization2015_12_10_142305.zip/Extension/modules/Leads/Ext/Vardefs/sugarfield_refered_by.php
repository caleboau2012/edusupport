<?php
 // created: 2015-10-29 20:17:43
$dictionary['Lead']['fields']['refered_by']['inline_edit']=true;
$dictionary['Lead']['fields']['refered_by']['comments']='Identifies who refered the lead';
$dictionary['Lead']['fields']['refered_by']['merge_filter']='disabled';

 ?>