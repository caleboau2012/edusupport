<?php
 // created: 2015-10-07 10:12:36
$dictionary['Lead']['fields']['sales_stage_c']['labelValue']='Sales Stage';

 ?>