<?php
 // created: 2015-10-26 08:58:48
$dictionary['Lead']['fields']['intended_course_of_study_c']['inline_edit']='1';
$dictionary['Lead']['fields']['intended_course_of_study_c']['labelValue']='intended course of study';

 ?>