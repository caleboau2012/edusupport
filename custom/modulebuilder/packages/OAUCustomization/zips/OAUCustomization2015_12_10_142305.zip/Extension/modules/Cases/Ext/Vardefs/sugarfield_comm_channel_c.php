<?php
 // created: 2015-06-24 08:24:06
$dictionary['Case']['fields']['comm_channel_c']['labelValue']='Communication Channel';

 ?>