<?php
 // created: 2015-10-23 06:03:32
$dictionary['Lead']['fields']['reason_c']['inline_edit']='1';
$dictionary['Lead']['fields']['reason_c']['labelValue']='Reason';

 ?>