<?php
 // created: 2015-10-13 03:34:10
$dictionary['Case']['fields']['referred_by_c']['inline_edit']='1';
$dictionary['Case']['fields']['referred_by_c']['labelValue']='How you heard about us';

 ?>