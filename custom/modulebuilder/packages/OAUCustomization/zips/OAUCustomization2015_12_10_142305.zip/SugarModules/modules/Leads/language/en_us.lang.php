<?php 
 // created: 2015-12-10 14:23:01
$mod_strings['LBL_BUYING_POWER'] = 'Buying Power';
$mod_strings['LBL_INTEREST'] = 'Interest';
$mod_strings['LBL_SALES_STAGE'] = 'Sales Stage';
$mod_strings['LBL_REFERED_BY'] = 'Referred by';
$mod_strings['LBL_REASON'] = 'Reason';
$mod_strings['LBL_INTENDED_COURSE_OF_STUDY'] = 'intended course of study';
$mod_strings['LBL_LEAD_SOURCE_DESCRIPTION'] = 'How you heard about us';
$mod_strings['LBL_DATE_MODIFIED'] = 'Date Modified';

?>
